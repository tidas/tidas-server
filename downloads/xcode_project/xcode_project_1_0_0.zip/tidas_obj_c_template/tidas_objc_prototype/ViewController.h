//
//  ViewController.h
//  tidas_objc_prototype
//
//  Created by ryan on 7/1/15.
//  Copyright © 2015 trailofbits. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

- (void)validate;

@end

